# Portfolio Website Creation Plan

## Steps to Complete:
- [x] Create index.html with HTML structure including photo placeholder, biodata, and short explanation
- [x] Create styles.css with attractive soft light green design
- [x] Test the website by opening in browser
- [x] Create education.html page with school history
- [x] Update index.html to link to education page
- [x] Test the new page
- [x] Create strengths.html page with personal strengths
- [x] Update index.html to link to strengths page
- [x] Test the new page
- [ ] Create kelebihan.html page with additional strengths
- [ ] Update index.html to link to kelebihan page
- [ ] Test the new page
